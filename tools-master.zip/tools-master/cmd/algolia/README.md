# Algolia

## `update`

Updates the Algolia search index based on the prebuilt `package.min.js`.
